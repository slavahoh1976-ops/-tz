LED Pixel Mask Generator 3.0.33
Windows/  — программа для Windows (.exe)
Mac/      — программа для Mac (.zip с .app внутри; распаковать и перенести в «Программы»)
Android/  — установочный файл для Android (.apk)
Web/      — веб-версия одним файлом, открывается в браузере
LED-Pixel-Mask-Generator-src-3.0.33.zip — исходники (сборка: python build_web.py)
Веб-версия онлайн: https://slavahoh1976-ops.github.io/-tz/
