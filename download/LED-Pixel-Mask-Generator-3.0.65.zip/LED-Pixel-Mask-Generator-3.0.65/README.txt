LED Pixel Mask Generator 3.0.65
Windows/  — программа для Windows: …-Windows.exe (без установки) и …-Windows-Setup.exe (установщик)
Mac/      — программа для Mac (.zip с .app внутри; распаковать и перенести в «Программы»)
Android/  — установочный файл для Android (.apk)
Web/      — веб-версия одним файлом, открывается в браузере
LED-Pixel-Mask-Generator-src-3.0.65.zip — исходники (сборка: python build_web.py)
Веб-версия онлайн: https://slavahoh1976-ops.github.io/-tz/
